class Tools
	require 'ostruct'
	require 'socket'
    require 'open3'
    require 'readline'
    

    #-----------[design]--------#
    @@design = Design::Design.new
    
    Readline.completion_append_character = " "
    Readline.completion_proc = Proc.new do |str|
        Dir.glob(str+'**/*.rb').grep(/^#{Regexp.escape(str)}/)
    end
    
    ls_rb = Dir.glob("modules/**/*.rb")
    ls_config = Dir["modules/**/*.conf"]
    ls_modules_exploit_rb = Dir["modules/exploit/*.rb"]
    ls_modules_exploit_conf = Dir["modules/exploit/*.conf"]
    ls_modules_aux_rb = Dir["modules/auxiliary/*.rb"]
    ls_modules_aux_conf = Dir["modules/auxiliary/*.conf"]
    ls_modules_payloads_rb = Dir["modules/payloads/*.rb"]
    ls_modules_payloads_conf = Dir["modules/payloads/*.conf"]
    ls_modules_post_rb = Dir["modules/posts/*.rb"]
    ls_modules_post_conf = Dir["modules/posts/*.conf"]
    
    count_rb_module = ls_rb.length
    count_rb_config = ls_config.length
    count_rb_modules_exploit = ls_modules_exploit_rb.length
    count_rb_modules_exploit_conf = ls_modules_exploit_conf.length
    count_rb_modules_aux = ls_modules_aux_rb.length
    count_rb_modules_aux_conf = ls_modules_aux_conf.length
    count_rb_modules_payloads = ls_modules_payloads_rb.length
    count_rb_modules_payloads_conf = ls_modules_payloads_conf.length
    count_rb_modules_posts = ls_modules_post_rb.length
    count_rb_modules_posts_conf = ls_modules_post_conf.length

    puts @@design.asciiMain
    @@design.Copyright
    
    puts "        ==========\033[1;91mModules Loadeds\033[00m========="
    puts "                   modules  : \033[1;91m#{count_rb_module}\033[00m"
    puts "                   exploit  : \033[1;91m#{count_rb_modules_exploit}\033[00m"
    puts "                   post     : \033[1;91m#{count_rb_modules_aux}\033[00m"
    puts "                   payloads : \033[1;91m#{count_rb_modules_payloads}\033[00m"
    puts ""
    puts ""
    
    while true
        trap("INT", "SIG_IGN")
        i = 0
        input = Readline.readline("\033[1;91m[\033[00mCentaurius@\033[1;91mMain]\033[00m$ ", true)

        if input.start_with? "use"
            while i<count_rb_module
                if input == "use #{ls_rb[i]}"
                    puts "modules selected :> #{ls_rb[i]}"
                    require "#{ls_rb[i]}"
                    console_load_modules = CentauriusModule.new
                    console_load_modules.Main
                    i= i+1
                
                elsif input =="use #{ls_rb[i]} "
                    puts "modules selected :> #{ls_rb[i]}"
                    require "#{ls_rb[i]}"
                    console_load_modules = CentauriusModule.new
                    console_load_modules.Main
                    i= i+1
                    
                else
                    i = i+1
                end
            end
        
        elsif input.start_with? "banner"
            puts @@design.asciiMain
            @@design.Copyright
        
        elsif input.start_with? "exit"
            puts "\033[1;91m[!] Thanks For Using Centaurius !\033[00m"
            exit
        
        elsif input.start_with? "quit"
            puts "\033[1;91m[!] Thanks For Using Centaurius !\033[00m"
            exit
        
        elsif input.start_with? "cls"
            system("clear")
        
        elsif input.start_with? "clear"
            system("clear")

        else
            @@design.error {puts "[!] \033[1;93m#{input}\033[00m Unknow command !"}
        end
    end
end